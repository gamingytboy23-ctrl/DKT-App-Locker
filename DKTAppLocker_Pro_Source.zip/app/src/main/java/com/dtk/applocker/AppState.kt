package com.dtk.applocker

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.Intent

data class AppItem(
    val packageName: String,
    val label: String,
    val icon: android.graphics.drawable.Drawable?,
    val locked: Boolean = false,
    val dailyLimitMinutes: Int = 60
)

class AppState(context: Context) {
    private val prefs = context.getSharedPreferences("dkt_prefs", Context.MODE_PRIVATE)

    fun isLocked(packageName: String): Boolean =
        prefs.getBoolean("locked_$packageName", false)

    fun setLocked(packageName: String, value: Boolean) {
        prefs.edit().putBoolean("locked_$packageName", value).apply()
    }

    fun getBlockedPackages(): Set<String> =
        prefs.all.filter { it.key.startsWith("locked_") && it.value == true }
            .map { it.key.removePrefix("locked_") }
            .toSet()

    fun loadLaunchableApps(pm: PackageManager): List<AppItem> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != "com.dtk.applocker" }
            .map {
                AppItem(
                    packageName = it.packageName,
                    label = pm.getApplicationLabel(it).toString(),
                    icon = pm.getApplicationIcon(it),
                    locked = isLocked(it.packageName)
                )
            }
            .sortedBy { it.label.lowercase() }
    }
}
