package com.dtk.applocker

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import java.util.Calendar

private val Navy = Color(0xFF070B16)
private val Card = Color(0xFF10182A)
private val Card2 = Color(0xFF141E33)
private val Blue = Color(0xFF4F8CFF)
private val Purple = Color(0xFF8B5CF6)
private val TextPrimary = Color(0xFFF4F7FF)
private val TextSecondary = Color(0xFF9AA7BF)

enum class Tab { HOME, APPS, SCHEDULE, STATS, PROFILE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DKTAppLockerApp() }
    }
}

@Composable
fun DKTAppLockerApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.HOME) }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    val state = remember { AppState(context) }

    LaunchedEffect(Unit) {
        apps = state.loadLaunchableApps(context.packageManager)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Navy,
            surface = Card,
            primary = Blue,
            secondary = Purple,
            onBackground = TextPrimary,
            onSurface = TextPrimary
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            Scaffold(
                containerColor = Navy,
                bottomBar = {
                    NavigationBar(containerColor = Card) {
                        NavItem(Icons.Default.Home, "Home", tab == Tab.HOME) { tab = Tab.HOME }
                        NavItem(Icons.Default.Apps, "Apps", tab == Tab.APPS) { tab = Tab.APPS }
                        NavItem(Icons.Default.Schedule, "Schedule", tab == Tab.SCHEDULE) { tab = Tab.SCHEDULE }
                        NavItem(Icons.Default.BarChart, "Stats", tab == Tab.STATS) { tab = Tab.STATS }
                        NavItem(Icons.Default.Person, "Profile", tab == Tab.PROFILE) { tab = Tab.PROFILE }
                    }
                }
            ) { padding ->
                Box(Modifier.padding(padding)) {
                    when (tab) {
                        Tab.HOME -> HomeScreen(apps)
                        Tab.APPS -> AppsScreen(apps) { pkg, locked ->
                            state.setLocked(pkg, locked)
                            apps = apps.map {
                                if (it.packageName == pkg) it.copy(locked = locked) else it
                            }
                        }
                        Tab.SCHEDULE -> ScheduleScreen()
                        Tab.STATS -> StatsScreen()
                        Tab.PROFILE -> ProfileScreen()
                    }
                }
            }
        }
    }
}

@Composable
private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, null) },
        label = { Text(label, fontSize = 11.sp) }
    )
}

@Composable
private fun HomeScreen(apps: List<AppItem>) {
    val context = LocalContext.current
    val locked = apps.count { it.locked }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Good morning 👋", color = TextSecondary, fontSize = 15.sp)
            Text("Stay focused, Ashok", color = TextPrimary, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Focus streak", "7 days", "🔥", Modifier.weight(1f))
                StatCard("Active locks", "$locked", "🔒", Modifier.weight(1f))
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Card2),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("Today's screen time", color = TextSecondary, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("2h 18m", color = TextPrimary, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    LinearProgressIndicator(
                        progress = { 0.58f },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(10.dp)),
                        color = Blue,
                        trackColor = Color(0xFF28344E)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("58% of your daily goal", color = TextSecondary, fontSize = 13.sp)
                }
            }
        }
        item {
            Text("Quick actions", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionCard(Icons.Default.Lock, "Quick Lock") {}
                ActionCard(Icons.Default.Timer, "Focus Mode") {}
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF15152C)),
                shape = RoundedCornerShape(22.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.EmojiEvents, null, tint = Purple, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Focus goal", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Reduce Instagram by 30 min today", color = TextSecondary, fontSize = 13.sp)
                    }
                    Text("72%", color = Blue, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, emoji: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Card)) {
        Column(Modifier.padding(16.dp)) {
            Text(emoji, fontSize = 20.sp)
            Spacer(Modifier.height(7.dp))
            Text(value, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(title, color = TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ActionCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, onClick: () -> Unit) {
    Card(
        Modifier.weight(1f).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Column(Modifier.padding(18.dp)) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun AppsScreen(apps: List<AppItem>, onToggle: (String, Boolean) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = apps.filter { it.label.contains(query, ignoreCase = true) }

    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("My Apps", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Choose the apps you want DKTAppLocker to control.", color = TextSecondary, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search apps") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered, key = { it.packageName }) { app ->
                AppRow(app) { onToggle(app.packageName, it) }
            }
        }
    }
}

@Composable
private fun AppRow(app: AppItem, onToggle: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Card)) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            app.icon?.let {
                androidx.compose.foundation.Image(
                    bitmap = it.toBitmap(48, 48).asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
                )
            } ?: Box(Modifier.size(46.dp).background(Card2, RoundedCornerShape(12.dp)))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(app.label, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(if (app.locked) "Locked" else "Not locked", color = TextSecondary, fontSize = 12.sp)
            }
            Switch(checked = app.locked, onCheckedChange = onToggle)
        }
    }
}

@Composable
private fun ScheduleScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Schedule Lock", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Automate your focus hours.", color = TextSecondary)
        Spacer(Modifier.height(18.dp))
        ScheduleCard("Instagram", "7:00 PM — 8:00 AM", "Every day", true)
        ScheduleCard("Games", "10:00 PM — 6:30 AM", "Mon — Fri", false)
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {},
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("Create schedule")
        }
    }
}

@Composable
private fun ScheduleCard(name: String, time: String, days: String, enabled: Boolean) {
    Card(
        Modifier.fillMaxWidth().padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Schedule, null, tint = Purple, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(time, color = TextSecondary, fontSize = 13.sp)
                Text(days, color = TextSecondary, fontSize = 12.sp)
            }
            Switch(enabled = enabled, checked = enabled, onCheckedChange = {})
        }
    }
}

@Composable
private fun StatsScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Statistics", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Your digital wellbeing overview", color = TextSecondary)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Screen time", "2h 18m", "⏱️", Modifier.weight(1f))
            StatCard("Time saved", "48m", "✨", Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.padding(18.dp)) {
                Text("Weekly usage", color = TextPrimary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                val bars = listOf(0.45f, 0.72f, 0.54f, 0.85f, 0.61f, 0.35f, 0.50f)
                Row(
                    Modifier.fillMaxWidth().height(170.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    bars.forEachIndexed { index, value ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.width(24.dp).fillMaxHeight(value).clip(RoundedCornerShape(8.dp))
                                    .background(if (index == 4) Purple else Blue)
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(listOf("M","T","W","T","F","S","S")[index], color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen() {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Profile", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Card)) {
            Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(62.dp).clip(CircleShape).background(Blue),
                    contentAlignment = Alignment.Center
                ) {
                    Text("A", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(15.dp))
                Column {
                    Text("Ashok", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Focus Member • 7 day streak", color = TextSecondary, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        ProfileItem(Icons.Default.Security, "Security", "Emergency unlock & strict mode")
        ProfileItem(Icons.Default.BarChart, "Usage Access", "Required for screen-time statistics") {
            context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        ProfileItem(Icons.Default.Accessibility, "App Blocking Service", "Enable DKTAppLocker in Android Accessibility") {
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        ProfileItem(Icons.Default.Settings, "Settings", "Notifications, appearance and data")
        ProfileItem(Icons.Default.HelpOutline, "Help & Support", "Learn how DKTAppLocker works")
    }
}

@Composable
private fun ProfileItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: (() -> Unit)? = null
) {
    Card(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable(enabled = onClick != null) { onClick?.invoke() },
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(27.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = TextSecondary, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextSecondary)
        }
    }
}
