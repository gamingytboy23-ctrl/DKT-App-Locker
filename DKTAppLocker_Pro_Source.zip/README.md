# DKTAppLocker — Pro Android Starter

A modern Jetpack Compose foundation for DKTAppLocker:
- Dark navy / blue / purple neon UI
- Home, Apps, Schedule, Stats, Profile
- Installed-app discovery
- Persistent lock toggles
- Usage Access and Accessibility settings shortcuts
- Accessibility service foundation for detecting blocked apps

## Build
This project targets Android API 36 and uses AGP 9.4.0 / Gradle 9.6 / Kotlin 2.3.21.

From the project root:
    ./gradlew :app:assembleDebug

The first build downloads Gradle/Android dependencies from Google Maven and Maven Central.

## Important
The accessibility service is a foundation only. Production-grade blocking should add:
- a dedicated blocked-screen activity
- schedules and daily-limit evaluation
- temporary emergency unlock
- secure hashed emergency code
- lock history
- foreground-service/boot handling where appropriate
- careful Android/Google Play policy compliance and user disclosure
